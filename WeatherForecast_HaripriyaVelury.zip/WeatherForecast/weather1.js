        
const suggestionsElement = document.getElementById('suggestions');  
const cityInput = document.getElementById('cityInput');  
const searchButton = document.getElementById('searchButton');  

// text input Search button - click event  
searchButton.addEventListener('click', () => {  
    if (cityInput.value.trim()==''){
    alert("empty search");}
    const city = cityInput.value.trim();  
    
    if (city) {  
        searchCity(city);  
        cityInput.value = ''; // Clear input field after searching  
    }  
});  

// Input event for displaying suggestions in dropdown  
cityInput.addEventListener('input', showSuggestions);  
cityInput.addEventListener('focus', showSuggestions);  

// Suggestions dropdown - click event  
suggestionsElement.addEventListener('click', (event) => {  
    if (event.target.tagName === 'LI') {  
        cityInput.value = event.target.innerText;  
        searchCity(event.target.innerText);  
        suggestionsElement.innerHTML = '';  
        suggestionsElement.classList.add('hidden');  
        cityInput.value = ''; // Clear input field  
    }  
});  

// Current location - button click event  
document.getElementById('currentLocationButton').addEventListener('click', () => {  
    if (navigator.geolocation) {  
        navigator.geolocation.getCurrentPosition(position => {  
            const { latitude, longitude } = position.coords;  
            getWeatherByCoords(latitude, longitude);  
        }, () => {  
            alert('Unable to retrieve your location.');  
        });  
    } else {  
        alert('Geolocation is not supported by this browser.');  
    }  
});  

// Hide dropdown when clicking outside  
document.addEventListener('click', (event) => 
{  
    const inputFieldActive = cityInput.contains(event.target) || suggestionsElement.contains(event.target);  
    if (!inputFieldActive) {  
        suggestionsElement.classList.add('hidden');  
    }  
});   

// Function that checks if a city is in the dropdown 
function searchCity(city) 
{  
    
    const searchedCities = JSON.parse(sessionStorage.getItem('searchedCities')) || [];  
    if (searchedCities.includes(city)) 
    {  
        getWeather(city);  
    } else {  
        getWeather(city);  
        saveCityToStorage(city);  
    }  
}  

async function getWeather(city) 
{  
    const apiKey = '88a12cd8080b4d90f67bd76bc65e53d0';   

    try {  
        // Fetch current weather data  
        const weatherResponse = await fetch(`https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${apiKey}&units=metric`);  
        if (!weatherResponse.ok) throw new Error('City not found');  

        const data = await weatherResponse.json();          
        // Fetch 5-day forecast data  
        const forecastResponse = await fetch(`https://api.openweathermap.org/data/2.5/forecast?q=${city}&appid=${apiKey}&units=metric`);  
        if (!forecastResponse.ok) throw new Error('Forecast data not available');  
        
        const forecastData = await forecastResponse.json();  
        
        // Save the weather data to session storage  
        sessionStorage.setItem('weatherData', JSON.stringify(data));  
        
        displayWeather(data, forecastData);  
    } catch (error) {  
        console.error('Error fetching weather data:', error);  
        alert('Could not fetch weather data. Please try again.'); 
    }  
}  

async function getWeatherByCoords(lat, lon) 
{  
    const apiKey = '88a12cd8080b4d90f67bd76bc65e53d0';   

    try 
    {  
        // Fetch current weather data by coordinates  
        const weatherResponse = await fetch(`https://api.openweathermap.org/data/2.5/weather?lat=${lat}&lon=${lon}&appid=${apiKey}&units=metric`);  
        if (!weatherResponse.ok) throw new Error('Weather data not available');  

        const data = await weatherResponse.json();  

        // Fetch 5-day forecast by coordinates  
        const forecastResponse = await fetch(`https://api.openweathermap.org/data/2.5/forecast?lat=${lat}&lon=${lon}&appid=${apiKey}`);  
        if (!forecastResponse.ok) throw new Error('Forecast data not available');  

        const forecastData = await forecastResponse.json();  

        // Save the weather data to session storage  
        sessionStorage.setItem('weatherData', JSON.stringify(data));   

        displayWeather(data, forecastData);  
    } 
    catch (error) 
    {  
        console.error('Error fetching weather data:', error);  
        alert('Could not fetch weather data. Please try again.'); // Inform the user  
    }  
}  

function displayWeather(data, forecast)
{  
    const weatherResult = document.getElementById('weatherResult');  
    const suggestionsElement = document.getElementById('suggestions'); 
    const today = new Date();  
    const options = { year: 'numeric', month: 'numeric', day: 'numeric' };  
    const currentDate = today.toLocaleDateString(undefined, options);  

    const iconCode = data.weather[0].icon;  
    const iconUrl = `https://openweathermap.org/img/wn/${iconCode}@2x.png`;  

    weatherResult.innerHTML = `  
        <div class="flex m-1 bg-blue-500 order p-4 rounded shadow-md mt-3 m-2">   
            <div class="weather-info text-white w-3/4 items-center justify-between">  
                <p class="text-xl font-semibold">${data.name}, ${data.sys.country} (${currentDate})</p>  
                <p>Temperature: ${data.main.temp} °C</p>  
                <p>Weather: ${data.weather[0].description}</p>  
                <p>Wind: ${data.wind.speed} m/s</p>  
                <p>Humidity: ${data.main.humidity}%</p>  
            </div>  
            <div class="flex text-white items-center justify-between weather-icon">  
                <p justify-content-centre><img src="${iconUrl}" class="w-15 h-15" alt="${data.weather[0].description}">  
                ${data.weather[0].description}</p>   
            </div>  
        </div>    
        <div class="forecast-container bg-gray-100 border p-4 rounded shadow-md mt-3 m-2">   
            <h3 class="text-lg font-semibold ">5-Day / 3 Hour Forecast</h3>  
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-6 gap-2 mt-4">   
            ${forecast.list.map(item => {  
                const date = new Date(item.dt * 1000); // Convert Unix timestamp to Date object  
                const formattedDate = date.toLocaleDateString(undefined, options); // Format date  

                    const formattedTime = date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
                    
                    const forecastIconCode = item.weather[0].icon;  
                    const forecastIconUrl = `https://openweathermap.org/img/wn/${forecastIconCode}@2x.png`;  
                    return `  
                        <div class="forecast-item bg-gray-300 p-2 border rounded-md shadow-sm">  
                            <p>${formattedDate} -  ${formattedTime}</p>
                            <img src="${forecastIconUrl}" alt="${item.weather[0].description}" class="w-20 h-20">  
                            <p>Temp: ${item.main.temp} °C</p>  
                            <p>Wind: ${item.wind.speed} m/s</p>  
                            <p>Humidity: ${item.main.humidity}%</p>  
                        </div>  
                    `;  
                }).join('')}  
            </div>  
        </div>  
    `;  

    suggestionsElement.classList.add('hidden'); // hides suggestions after weather data loaded  
}  

function saveCityToStorage(city) {  
    let searchedCities = JSON.parse(sessionStorage.getItem('searchedCities')) || [];  
    if (!searchedCities.includes(city)) {  
        searchedCities.push(city);  
        sessionStorage.setItem('searchedCities', JSON.stringify(searchedCities));  
    }  
}  

function showSuggestions() {  
    const searchedCities = JSON.parse(sessionStorage.getItem('searchedCities')) || [];  
    suggestionsElement.innerHTML = '';  

    if (searchedCities.length > 0) {  
        searchedCities.forEach(city => {  
            const li = document.createElement('li');  
            li.textContent = city;  
            li.className = 'cursor-pointer p-2 hover:bg-gray-200';  
            suggestionsElement.appendChild(li);  
        });  
        suggestionsElement.classList.remove('hidden');  
    } else {  
        suggestionsElement.classList.add('hidden');  
    }  
}  

// Optionally, load weather data from session storage on page load  
window.onload = () => {  
    const storedWeather = sessionStorage.getItem('weatherData');  
    if (storedWeather) {  
        displayWeather(JSON.parse(storedWeather));  
    }  
};